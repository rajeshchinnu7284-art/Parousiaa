export * from "./faculty";
export * from "./students";
export * from "./timetable";
export * from "./attendance";
