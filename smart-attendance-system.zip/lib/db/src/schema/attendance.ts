import { pgTable, serial, integer, text, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { studentsTable } from "./students";
import { timetableTable } from "./timetable";

export const attendanceTable = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentsTable.id, { onDelete: "cascade" }),
  timetableId: integer("timetable_id").notNull().references(() => timetableTable.id, { onDelete: "cascade" }),
  date: date("date").notNull(),
  status: text("status", { enum: ["Present", "Absent"] }).notNull(),
  markedBy: text("marked_by").notNull().default("manual"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({ id: true, timestamp: true });
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type AttendanceRecord = typeof attendanceTable.$inferSelect;
