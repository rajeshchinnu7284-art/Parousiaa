import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import studentsRouter from "./students";
import timetableRouter from "./timetable";
import attendanceRouter from "./attendance";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/students", studentsRouter);
router.use("/timetable", timetableRouter);
router.use("/attendance", attendanceRouter);

export default router;
