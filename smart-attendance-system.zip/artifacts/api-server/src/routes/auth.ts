import { Router, type IRouter } from "express";
import { db, facultyTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { z } from "zod";

const router: IRouter = Router();

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

router.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { email, password } = parsed.data;
  const [faculty] = await db.select().from(facultyTable).where(eq(facultyTable.email, email)).limit(1);

  if (!faculty) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  const valid = await bcrypt.compare(password, faculty.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }

  (req.session as any).facultyId = faculty.id;

  res.json({
    faculty: {
      id: faculty.id,
      name: faculty.name,
      email: faculty.email,
      department: faculty.department,
    },
    message: "Login successful",
  });
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ message: "Logged out" });
  });
});

router.get("/me", async (req, res) => {
  const facultyId = (req.session as any).facultyId;
  if (!facultyId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [faculty] = await db.select().from(facultyTable).where(eq(facultyTable.id, facultyId)).limit(1);
  if (!faculty) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  res.json({
    id: faculty.id,
    name: faculty.name,
    email: faculty.email,
    department: faculty.department,
  });
});

export default router;
