import React, { useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGetStudent, useCreateStudent, useUpdateStudent } from "@workspace/api-client-react";
import { Card, Button, Input, Select } from "@/components/ui-core";
import { ArrowLeft, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const studentSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  registerNumber: z.string().min(5, "Register number is required"),
  department: z.string().min(1, "Department is required"),
  year: z.string().min(1, "Year is required"),
  section: z.string().min(1, "Section is required"),
  photoPath: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type StudentFormValues = z.infer<typeof studentSchema>;

export default function StudentForm() {
  const { id } = useParams();
  const isEditing = !!id;
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: student, isLoading: isLoadingStudent } = useGetStudent(Number(id), {
    query: { enabled: isEditing }
  });

  const createMutation = useCreateStudent({
    mutation: {
      onSuccess: () => {
        toast({ title: "Student created successfully!" });
        setLocation("/students");
      },
      onError: () => toast({ title: "Failed to create student", variant: "destructive" })
    }
  });

  const updateMutation = useUpdateStudent({
    mutation: {
      onSuccess: () => {
        toast({ title: "Student updated successfully!" });
        setLocation("/students");
      },
      onError: () => toast({ title: "Failed to update student", variant: "destructive" })
    }
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm<StudentFormValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: {
      name: "", registerNumber: "", department: "", year: "", section: "", photoPath: ""
    }
  });

  useEffect(() => {
    if (student && isEditing) {
      reset({
        name: student.name,
        registerNumber: student.registerNumber,
        department: student.department,
        year: student.year,
        section: student.section,
        photoPath: student.photoPath || "",
      });
    }
  }, [student, isEditing, reset]);

  const onSubmit = (data: StudentFormValues) => {
    if (isEditing) {
      updateMutation.mutate({ id: Number(id), data });
    } else {
      createMutation.mutate({ data });
    }
  };

  if (isEditing && isLoadingStudent) {
    return <div className="flex justify-center p-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/students")}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-4xl font-display font-bold text-foreground">
            {isEditing ? "Edit Student" : "Add New Student"}
          </h1>
          <p className="text-muted-foreground mt-1 text-lg">Enter the student's details below.</p>
        </div>
      </div>

      <Card className="p-8">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold mb-2">Full Name</label>
              <Input {...register("name")} placeholder="John Doe" error={errors.name?.message} />
            </div>
            
            <div>
              <label className="block text-sm font-semibold mb-2">Register Number</label>
              <Input 
                {...register("registerNumber")} 
                placeholder="REG12345" 
                disabled={isEditing} 
                error={errors.registerNumber?.message} 
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Department</label>
              <Select {...register("department")} error={errors.department?.message}>
                <option value="">Select Department...</option>
                <option value="CSE">Computer Science (CSE)</option>
                <option value="ECE">Electronics (ECE)</option>
                <option value="MECH">Mechanical (MECH)</option>
                <option value="CIVIL">Civil</option>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Year</label>
              <Select {...register("year")} error={errors.year?.message}>
                <option value="">Select Year...</option>
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Section</label>
              <Select {...register("section")} error={errors.section?.message}>
                <option value="">Select Section...</option>
                <option value="A">Section A</option>
                <option value="B">Section B</option>
                <option value="C">Section C</option>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">Photo URL (Optional)</label>
              <Input {...register("photoPath")} placeholder="https://..." error={errors.photoPath?.message} />
            </div>
          </div>

          <div className="pt-6 flex justify-end gap-4 border-t border-border">
            <Button type="button" variant="ghost" onClick={() => setLocation("/students")}>Cancel</Button>
            <Button type="submit" isLoading={createMutation.isPending || updateMutation.isPending}>
              <Save className="w-5 h-5 mr-2" /> {isEditing ? "Save Changes" : "Create Student"}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
