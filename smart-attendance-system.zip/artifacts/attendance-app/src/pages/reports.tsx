import React, { useState } from "react";
import { useGetAttendanceSummary, useExportAttendance } from "@workspace/api-client-react";
import { Card, Button, Select, Badge } from "@/components/ui-core";
import { Download, Filter, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Reports() {
  const [deptFilter, setDeptFilter] = useState("");
  const [yearFilter, setYearFilter] = useState("");
  const { toast } = useToast();

  const { data: summary, isLoading } = useGetAttendanceSummary({
    department: deptFilter || undefined,
    year: yearFilter || undefined,
  });

  const exportMutation = useExportAttendance({
    mutation: {
      onSuccess: (csvData) => {
        const blob = new Blob([csvData], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `attendance_report_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        toast({ title: "Export successful", description: "CSV downloaded." });
      },
      onError: () => toast({ title: "Export failed", variant: "destructive" })
    }
  });

  const handleExport = () => {
    exportMutation.mutate({ request: undefined });
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-display font-bold text-foreground">Attendance Reports</h1>
          <p className="text-muted-foreground mt-2 text-lg">Detailed student attendance statistics.</p>
        </div>
        <Button onClick={handleExport} isLoading={exportMutation.isPending}>
          <Download className="w-5 h-5 mr-2" /> Export to Excel (CSV)
        </Button>
      </div>

      <Card className="p-4 sm:p-6 flex flex-col md:flex-row gap-4 items-center bg-muted/20">
        <div className="flex items-center gap-2 text-muted-foreground mr-4">
          <Filter className="w-5 h-5" /> <span className="font-bold">Filters:</span>
        </div>
        <Select value={deptFilter} onChange={e => setDeptFilter(e.target.value)} className="w-full md:w-64 bg-white">
          <option value="">All Departments</option>
          <option value="CSE">CSE</option>
          <option value="ECE">ECE</option>
        </Select>
        <Select value={yearFilter} onChange={e => setYearFilter(e.target.value)} className="w-full md:w-64 bg-white">
          <option value="">All Years</option>
          <option value="1">1st Year</option>
          <option value="2">2nd Year</option>
          <option value="3">3rd Year</option>
          <option value="4">4th Year</option>
        </Select>
      </Card>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-primary text-primary-foreground font-display text-sm tracking-wider uppercase">
                <th className="p-4 font-bold rounded-tl-2xl">Student Details</th>
                <th className="p-4 font-bold">Class / Dept</th>
                <th className="p-4 font-bold">Total Classes</th>
                <th className="p-4 font-bold text-success">Present</th>
                <th className="p-4 font-bold text-destructive">Absent</th>
                <th className="p-4 font-bold rounded-tr-2xl">Percentage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  </td>
                </tr>
              ) : summary?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-muted-foreground font-medium">
                    No data available for the selected filters.
                  </td>
                </tr>
              ) : (
                summary?.map((row) => (
                  <tr key={row.studentId} className={`hover:bg-accent/20 transition-colors ${row.isLowAttendance ? 'bg-warning/5' : ''}`}>
                    <td className="p-4">
                      <p className="font-bold text-foreground">{row.studentName}</p>
                      <p className="text-xs text-muted-foreground font-mono mt-1">{row.registerNumber}</p>
                    </td>
                    <td className="p-4 text-sm font-medium">
                      {row.department} • Yr {row.year} • {row.section}
                    </td>
                    <td className="p-4 font-bold text-lg">{row.totalClasses}</td>
                    <td className="p-4 font-bold text-lg text-success">{row.presentCount}</td>
                    <td className="p-4 font-bold text-lg text-destructive">{row.absentCount}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <span className={`font-display font-bold text-xl ${row.percentage < 75 ? 'text-destructive' : 'text-success'}`}>
                          {row.percentage}%
                        </span>
                        {row.isLowAttendance && (
                          <Badge variant="danger" className="text-[10px] uppercase gap-1 flex items-center">
                            <AlertTriangle className="w-3 h-3" /> Warning
                          </Badge>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
