import React, { useState, useEffect } from "react";
import { Card, Badge } from "@/components/ui-core";
import { Camera, Users, CheckCircle } from "lucide-react";
import { useListStudents } from "@workspace/api-client-react";

export default function AttendanceLive() {
  const { data: students } = useListStudents();
  const [recognized, setRecognized] = useState<any[]>([]);
  
  // Simulate face recognition events
  useEffect(() => {
    if (!students || students.length === 0) return;
    
    const interval = setInterval(() => {
      // Pick a random student not yet recognized
      const available = students.filter(s => !recognized.find(r => r.id === s.id));
      if (available.length > 0) {
        const randomStudent = available[Math.floor(Math.random() * available.length)];
        setRecognized(prev => [{...randomStudent, timestamp: new Date()}, ...prev]);
      }
    }, 3000); // New recognition every 3 seconds

    return () => clearInterval(interval);
  }, [students, recognized]);

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-4xl font-display font-bold text-foreground">Live Feed</h1>
          <Badge variant="danger" className="animate-pulse px-3 py-1 text-sm"><span className="w-2 h-2 rounded-full bg-white mr-2" /> LIVE</Badge>
        </div>
        <p className="text-muted-foreground mt-2 text-lg">AI Face Recognition active. Marking attendance automatically.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Camera Feed Simulator */}
        <Card className="lg:col-span-2 overflow-hidden bg-black aspect-video relative flex items-center justify-center">
          <div className="absolute inset-0 scanner-line z-10 pointer-events-none" />
          
          <div className="text-center text-white/50 z-0">
            <Camera className="w-20 h-20 mx-auto mb-4 opacity-50" />
            <p className="font-display text-xl tracking-widest uppercase">Camera Feed — RTSP/Webcam</p>
            <p className="text-sm mt-2 font-mono">Status: Connected • FPS: 24 • Model: Active</p>
          </div>
          
          {/* Simulated bounding boxes for recent recognition */}
          {recognized.slice(0, 1).map((r, i) => (
            <div key={i} className="absolute inset-20 border-2 border-success rounded-xl bg-success/10 flex items-end justify-center pb-4 transition-all duration-500 animate-in zoom-in">
              <Badge variant="success" className="text-lg px-4 py-1 animate-bounce">
                {r.name} Match 98%
              </Badge>
            </div>
          ))}
        </Card>

        {/* Log Sidebar */}
        <Card className="flex flex-col h-[400px] lg:h-auto">
          <div className="p-6 border-b border-border bg-muted/20 flex justify-between items-center">
            <h2 className="font-bold font-display text-xl">Recognized Log</h2>
            <div className="flex items-center gap-2 text-success font-bold bg-success/10 px-3 py-1 rounded-lg">
              <Users className="w-4 h-4" /> {recognized.length}
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {recognized.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground text-sm text-center">
                <p>Waiting for subjects in frame...</p>
              </div>
            ) : (
              recognized.map(student => (
                <div key={student.id} className="flex items-center gap-4 p-3 rounded-xl border border-success/30 bg-success/5 animate-in slide-in-from-left-4 fade-in duration-300">
                  <div className="w-10 h-10 rounded-full bg-success flex items-center justify-center text-white">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-foreground truncate">{student.name}</p>
                    <p className="text-xs text-muted-foreground">{student.registerNumber} • {student.timestamp.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
