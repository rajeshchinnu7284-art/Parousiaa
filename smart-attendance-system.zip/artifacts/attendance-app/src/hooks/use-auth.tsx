import React, { createContext, useContext, useEffect } from "react";
import { useGetMe, useLogin, useLogout } from "@workspace/api-client-react";
import type { Faculty, LoginRequest } from "@workspace/api-client-react/src/generated/api.schemas";
import { useLocation } from "wouter";
import { parseApiError } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface AuthContextType {
  user: Faculty | null;
  isLoading: boolean;
  login: (data: LoginRequest) => void;
  logout: () => void;
  isLoggingIn: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: user, isLoading, error, refetch } = useGetMe({
    query: {
      retry: false,
      staleTime: Infinity,
    },
  });

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Welcome back!", description: data.message });
        refetch();
        setLocation("/dashboard");
      },
      onError: (err: any) => {
        toast({ 
          title: "Login failed", 
          description: parseApiError(err), 
          variant: "destructive" 
        });
      },
    }
  });

  const logoutMutation = useLogout({
    mutation: {
      onSuccess: () => {
        refetch();
        setLocation("/login");
      }
    }
  });

  const handleLogin = (data: LoginRequest) => {
    loginMutation.mutate({ data });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <AuthContext.Provider value={{
      user: user || null,
      isLoading,
      login: handleLogin,
      logout: handleLogout,
      isLoggingIn: loginMutation.isPending
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
