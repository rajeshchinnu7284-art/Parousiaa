import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { AuthProvider } from "@/hooks/use-auth";
import { AppLayout } from "@/components/layout";

// Pages
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Students from "@/pages/students";
import StudentForm from "@/pages/student-form";
import Timetable from "@/pages/timetable";
import Attendance from "@/pages/attendance";
import AttendanceLive from "@/pages/attendance-live";
import Reports from "@/pages/reports";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Protected Routes wrapped in Layout */}
      <Route path="/dashboard"><AppLayout><Dashboard /></AppLayout></Route>
      <Route path="/students"><AppLayout><Students /></AppLayout></Route>
      <Route path="/students/add"><AppLayout><StudentForm /></AppLayout></Route>
      <Route path="/students/edit/:id"><AppLayout><StudentForm /></AppLayout></Route>
      <Route path="/timetable"><AppLayout><Timetable /></AppLayout></Route>
      <Route path="/attendance"><AppLayout><Attendance /></AppLayout></Route>
      <Route path="/attendance/live"><AppLayout><AttendanceLive /></AppLayout></Route>
      <Route path="/reports"><AppLayout><Reports /></AppLayout></Route>
      
      {/* Default route redirects to dashboard (or login if unauth via hook) */}
      <Route path="/"><AppLayout><Dashboard /></AppLayout></Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
